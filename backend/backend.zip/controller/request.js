exports.getRequestFromUser = (req, res, next) => {
  const email = req.body.email;
  const request = req.body.txtAreaInput;

  console.log(email);
  console.log(request);
  res.redirect("/request.html");
};
